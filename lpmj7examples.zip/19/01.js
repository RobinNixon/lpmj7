function byId(id)
{
  return document.getElementById(id)
}
