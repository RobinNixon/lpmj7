function byId(id)
{
  return document.getElementById(id)
}

function style(selector)
{
  return document.querySelector(selector).style
}

function by(selector)
{
  return document.querySelectorAll(selector)
}
