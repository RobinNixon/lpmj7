function style(selector)
{
  return document.querySelector(selector).style
}
