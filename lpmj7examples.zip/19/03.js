function by(selector)
{
  return document.querySelectorAll(selector)
}
