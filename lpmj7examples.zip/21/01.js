function helloWorld()
{
  return 'Hello World'
}

export { helloWorld }
