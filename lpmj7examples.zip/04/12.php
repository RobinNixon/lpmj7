<?php
  $month = "March";

  if ($month == "April") echo "A quarter of a year has passed";
?>
