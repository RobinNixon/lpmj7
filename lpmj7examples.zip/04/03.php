<?php
  $myname = "Brian";
  $myage  = 37;

  echo "a: " . 73      . "<br>"; // Numeric literal
  echo "b: " . "Hello" . "<br>"; // String literal
  echo "c: " . $myname . "<br>"; // String variable
  echo "d: " . $myage  . "<br>"; // Numeric variable
?>
