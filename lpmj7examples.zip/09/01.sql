CREATE TABLE accounts (
 number INT, balance INT, PRIMARY KEY(number)
 ) ENGINE InnoDB;
DESCRIBE accounts;
