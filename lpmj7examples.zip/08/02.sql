this is "meaningless gibberish" \c
