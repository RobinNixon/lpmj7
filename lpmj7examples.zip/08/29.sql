SELECT name,author,title FROM customers,classics
 WHERE customers.isbn=classics.isbn;
